# Input reading
n = int(input())
arr = list(map(int, input().split()))

# Precompute:
hash = [0] * 13  # since numbers are assumed to be <= 12

for i in range(n):
    hash[arr[i]] += 1

# Query
q = int(input())
for _ in range(q):
    number = int(input())
    print(hash[number])
